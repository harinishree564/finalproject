package com.example.demo.controller;




import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class StudentController {

@Autowired
StudentRepository repository;



@GetMapping("/Getstudents")
public List<Student> getStudents()
{
return repository.findAll();

}

@PostMapping("/student")
public void addStudent(@RequestBody Student ss)
{



repository.save(ss);
}

@PostMapping("/deletestudent/{id}")
public void deleteStudent(@PathVariable String id)
{
repository.deleteById(id);
}

@PostMapping("/updatestudent/{id}")
public void updateStudents(@PathVariable String id, @RequestBody Student s) {
repository.getById(id);
repository.save(s);
}

}