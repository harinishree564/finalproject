import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { StudentService } from '../student.service';


@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  logout(){
    alert("Are you sure,you want to logout?")
  }

 

  students!:Student[];
  getStudents: any;
  constructor(private studentService:StudentService, private https:HttpClient) { }
  onSubmit(data:Student)
  {
    this.https.post('http://localhost:8089/api/student',data).subscribe((result)=>
    console.warn("result",result));
    console.log(data);
  }

  ngOnInit(): void {
    this.studentService.getStudents().subscribe((data:Student[])=>
    {
      console.log(data);
      this.students = data;
    }
    );
  }

  ondelete(data:Student){

    this.https.post('http://localhost:8089/api/deletestudent/'+`${data.id}`,data).subscribe((result)=>{console.log(result)})
  
    window.location.reload();
  
  }

  // updateStudent(id: number){
  //   this.router.navigate(['update', id]);
  // }

  // deleteStudent(id:number){
  //   this.studentService.deleteStudent(id).subscribe( data => {
  //     console.log(data);
  //     this.getStudents();
  //   })
  // }

  }



