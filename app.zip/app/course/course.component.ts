import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  course= [
    {'id':1,'name':'Learn Angular','description':'AngularJS was one of the first modern JavaScript front-end frameworks.','image':'https://tsh.io/wp-content/uploads/2019/08/angular-8-new-features_.png'},
    {'id':2,'name':'Learn Typescript','description':'TypeScript is a strongly typed, object oriented, compiled language.','image':'https://www.tutorialandexample.com/wp-content/uploads/2019/01/typescript-tutorial.png'},
    {'id':3,'name':'Learn Nodejs','description':'Node.js is an open source, cross-platform runtime environment for developing server-side.','image':'https://www.webrexstudio.com/wp-content/uploads/2019/06/Node-js.jpg'},
    {'id':4,'name':'Learn Reactjs','description':'React is a User Interface (UI) library,created by facebook','image':'https://www.goodworklabs.com/wp-content/uploads/2016/10/reactjs.png'},
  ]
}