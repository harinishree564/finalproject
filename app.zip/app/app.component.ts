import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Student } from './student';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'eeducation-frontend';
  constructor(private https:HttpClient){}
    onSubmit(data:Student)
    {
      this.https.post('http://localhost:8089/api/student',data).subscribe((result)=>
      console.warn("result",result));
      console.log(data);
    }
}
