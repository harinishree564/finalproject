export class Student {
    id!:string;
    name!:string;
    email!: string;
    course!:string;
}
