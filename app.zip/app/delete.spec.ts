import { Delete } from './delete';

describe('Delete', () => {
  it('should create an instance', () => {
    expect(new Delete()).toBeTruthy();
  });
});
